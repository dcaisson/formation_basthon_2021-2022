from random import randint

def simulation(n):
    resultats = [0, 0, 0, 0, 0, 0]
    for i in range(n):
        de = randint(1, 6)
        resultats[de - 1] = resultats[de - 1] + 1
    return resultats

print(simulation(10000))